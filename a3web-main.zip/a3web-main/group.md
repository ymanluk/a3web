



Task - Person in charge - Timeline

CSS (basic template):
Menubar (home, projects, about, contact us) - Lok - completed
Resonsive Design & CSS styles for general html tags - Tam - completed
Header and Footer - Tam & Hong - completed
Main content design (overal structure for all pages) - Lok - completed

Javascript, use of javascript in particular page(s) - Chung - completed

Content, html & CSS (text, images, table (if needed) tags, classes and ids for specific pages, with comments) by page/topic
Homepage - Lok - completed
About - Hong - completed
Contact Us - Luk - completed
Remote Sensing & Survey - Hong - completed
Programming & Website - Luk - completed
Database Management - Lok - completed
Data Visualization & Spatial Analysis - Chung - completed

Proofreading:
Check error - All - completed
Check unused CSS - All - completed
Text proofread - All - completed

Git Master repository - Lok - completed